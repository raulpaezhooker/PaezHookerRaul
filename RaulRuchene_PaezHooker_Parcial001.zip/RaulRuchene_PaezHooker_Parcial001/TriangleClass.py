import math
import matplotlib.pylab as plt
import numpy as np

class Triangle:

        def __init__(self,sampling, bits, time):
            self.SamplingRate = sampling
            self.NumeroBit = bits
            self.Seconds = time
            #self.Frecuencia = frecuencia
            self.tamano = int(sampling * time)




        def generar(self):
            la=440
            fa=349.23
            re=293.66
            mi=329.63
            sol=392
            re5=587.33
            do5=523.25
            sib=46616
            reb=277.18
            wavearray = []
            datos = 0


            for i in range(0, self.tamano):
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*la*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)

            for i in range(0, (self.tamano/2)):
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)


            for i in range(0, (self.tamano/2)):#fa

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)


            for i in range(0, (self.tamano)):#sol

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*sol*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)

            for i in range(0, (self.tamano/2)):#fa

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#mi

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*mi*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano)):#re

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*re*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#re

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*re*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#fa

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, self.tamano):

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*la*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#sol

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*sol*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)

            for i in range(0, (self.tamano/2)):#fa

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano)):#mi

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*mi*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)


            for i in range(0, (self.tamano/2)):#mi

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*mi*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)

            for i in range(0, (self.tamano/2)):#fa

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)


            for i in range(0, (self.tamano)):#sol

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*sol*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, self.tamano):

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*la*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano)):#fa

                     A = 0.5-(1 / math.pi)
                     datos = 0
                     for j in range (1, 100):

                        value = (1/float(j))*math.sin((j*math.pi*fa*i)/self.SamplingRate)
                        datos += value
                     frame = datos * A
                     wavearray.append(frame)

            for i in range(0, (self.tamano)):#re

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*re*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)


            for i in range(0, (self.tamano*2)):#re

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*re*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#silencio

                    datos = math.sin((2*math.pi*0*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano)):#sol

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*sol*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#sib466.16

                     A = 0.5-(1 / math.pi)
                     datos = 0
                     for j in range (1, 100):

                        value = (1/float(j))*math.sin((j*math.pi*sib*i)/self.SamplingRate)
                        datos += value
                     frame = datos * A
                     wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#re5

                     A = 0.5-(1 / math.pi)
                     datos = 0
                     for j in range (1, 100):

                        value = (1/float(j))*math.sin((j*math.pi*re5*i)/self.SamplingRate)
                        datos += value
                     frame = datos * A
                     wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#re5

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*re5*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#do5

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*do5*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#sib466.16

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*sib*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, ((self.tamano/2)+self.tamano)):#la

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*la*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#fa

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#la

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*la*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#la

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*la*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#sol

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*sol*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)

            for i in range(0, (self.tamano/2)):#fa

                     A = 0.5-(1 / math.pi)
                     datos = 0
                     for j in range (1, 100):

                        value = (1/float(j))*math.sin((j*math.pi*fa*i)/self.SamplingRate)
                        datos += value
                     frame = datos * A
                     wavearray.append(frame)
            for i in range(0, (self.tamano)):#mi

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)

            for i in range(0, (self.tamano/2)):#mi

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*mi*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano/2)):#fa

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)


            for i in range(0, (self.tamano)):#sol

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*sol*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, self.tamano):

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*la*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano)):#fa

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano)):#re

                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*re*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)

            for i in range(0, (self.tamano*2)):#re
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*re*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano*2)):#re
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*re*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano*2)):# comps silencio
             datos = math.sin((2*math.pi*0*i)/self.SamplingRate)

             wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#fa
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano*2)):#re
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*re*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano*2)):#reb
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*reb*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano*2)):#mi
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*mi*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano*2)):#la
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*la*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano*2)):#fa
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano*2)):#sol
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*sol*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            for i in range(0, (self.tamano*2)):#mi
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*mi*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)

            for i in range(0, (self.tamano*2)):#fa
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)

            for i in range(0, (self.tamano*2)):#fa
                    A = (8 / math.pi**2)

                    for j in range (0, 100):
                        par = j % 2
                        if par:
                            val = (-1**((j-1)/2.0))/float(j)**2
                            value =  val * math.sin((j*math.pi*fa*i)/self.SamplingRate)
                            datos += value
                    frame = datos * A
                    wavearray.append(frame)
            FinalData = np.asarray(wavearray)

            return FinalData


        def leveladjust(self, datos, bits, level):
            peaklevel = max(abs(datos))
            valueLevel = (10**(level/20))*((2**16)/2.0)
            valueAdjust = valueLevel / float(peaklevel)
            datosAjustados = datos * valueAdjust
            return datosAjustados

