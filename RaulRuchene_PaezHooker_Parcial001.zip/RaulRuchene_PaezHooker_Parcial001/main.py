from Seno import Seno
from archivar import Archivo
#from SquareClass import Square
from TriangleClass import Triangle
from SawtoothClass import Sawtooth
#from Audiosystem import Audio


def main():

        print ("Generador de Onda Sinusoidal")
        Frecuenciadesampleo = 44100.0
        MaxBits = 16
        #Buffer = 1024
        Tiempo = 0.327
        la=440
        fa=349.23
        re=293.66
        mi=329.63
        sol=392
        re5=587.33
        do5=523.25
        sib=46616


        print ("Ingrese su opcion: ")
        #Tono = input("Digite la frecuencia del tono a generar: ")

        Level = -5
        Nombre = raw_input("Ingrese el nombre del archivo a generar: ")
        FormaDeOnda = input("Seleccione la forma de Onda deseada: 1.Seno  2.Diente de Sierra 3.Triangular  ")


        if (FormaDeOnda == 1):
                onda = Seno(Frecuenciadesampleo, MaxBits, Tiempo)
       # if (FormaDeOnda == 2):
               # onda = Square(Tono, Frecuenciadesampleo, MaxBits, Tiempo)
        if (FormaDeOnda == 2):
                onda = Sawtooth(Frecuenciadesampleo, MaxBits, Tiempo)
        if (FormaDeOnda == 3):
                onda = Triangle(Frecuenciadesampleo, MaxBits, Tiempo)

        datos = onda.generar()
        datosAjustados = onda.leveladjust(datos,MaxBits,Level)
        archivo = Archivo(Frecuenciadesampleo, MaxBits, Nombre)
        archivo.archivar(datosAjustados)

        #Seleccion = raw_input("Desea reproducir el audio generado(si/no): ")

       # if Seleccion == "si":
            #audio = Audio(Buffer)
            #Datos = audio.abrir(Nombre)
            #audio.inicio(Datos[0],Datos[1],Datos[2])
            #audio.reproducir(Datos[3])
            #audio.cerrar()


if __name__ == "__main__":
    main()