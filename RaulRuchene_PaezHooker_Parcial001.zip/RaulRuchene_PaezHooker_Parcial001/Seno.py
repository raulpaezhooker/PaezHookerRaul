import math
import matplotlib.pylab as plt
import numpy as np


class Seno:

        def __init__(self,sampling, bits, time):
            self.SamplingRate = sampling
            self.NumeroBit = bits
            self.Seconds = time
            #self.Frecuencia = frecuencia
            self.tamano = int(sampling * time)

        def generar(self):
           # 44100/120 = 367.5 @ 368 Cuadros/segundo 135=326.666666667ms o 327
            wavearray = []
            for i in range(0, self.tamano):

                    datos = math.sin((2*math.pi*440*i)/self.SamplingRate)#la

                    wavearray.append(datos)

            for i in range(0, (self.tamano/2)):#mi

                    datos = math.sin((2*math.pi*329.63*i)/self.SamplingRate)

                    wavearray.append(datos)

            for i in range(0, (self.tamano/2)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)


            for i in range(0, (self.tamano)):#sol

                    datos = math.sin((2*math.pi*392*i)/self.SamplingRate)

                    wavearray.append(datos)

            for i in range(0, (self.tamano/2)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#mi

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano)):#re

                    datos = math.sin((2*math.pi*293.66*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#re

                    datos = math.sin((2*math.pi*293.66*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)
                    wavearray.append(datos)
            for i in range(0, self.tamano):

                    datos = math.sin((2*math.pi*440*i)/self.SamplingRate)#la

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#sol

                    datos = math.sin((2*math.pi*392*i)/self.SamplingRate)

                    wavearray.append(datos)

            for i in range(0, (self.tamano/2)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano)):#mi

                    datos = math.sin((2*math.pi*329.63*i)/self.SamplingRate)

                    wavearray.append(datos)


            for i in range(0, (self.tamano/2)):#mi

                    datos = math.sin((2*math.pi*329.63*i)/self.SamplingRate)

                    wavearray.append(datos)

            for i in range(0, (self.tamano/2)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)


            for i in range(0, (self.tamano)):#sol

                    datos = math.sin((2*math.pi*392*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, self.tamano):

                    datos = math.sin((2*math.pi*440*i)/self.SamplingRate)#la

                    wavearray.append(datos)

            for i in range(0, (self.tamano)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)

            for i in range(0, (self.tamano)):#re

                    datos = math.sin((2*math.pi*293.66*i)/self.SamplingRate)

                    wavearray.append(datos)


            for i in range(0, (self.tamano*2)):#re

                    datos = math.sin((2*math.pi*293.66*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#silencio

                    datos = math.sin((2*math.pi*0*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano)):#sol

                    datos = math.sin((2*math.pi*392*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#sib466.16

                    datos = math.sin((2*math.pi*466.16*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#re5

                    datos = math.sin((2*math.pi*587.33*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#re5

                    datos = math.sin((2*math.pi*587.33*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#do5

                    datos = math.sin((2*math.pi*523.25*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#sib466.16

                    datos = math.sin((2*math.pi*466.16*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, ((self.tamano/2)+self.tamano)):#la

                    datos = math.sin((2*math.pi*440*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#la

                    datos = math.sin((2*math.pi*440*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#la

                    datos = math.sin((2*math.pi*440*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano/2)):#sol

                    datos = math.sin((2*math.pi*392*i)/self.SamplingRate)

                    wavearray.append(datos)

            for i in range(0, (self.tamano/2)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano)):#mi

                    datos = math.sin((2*math.pi*329.63*i)/self.SamplingRate)

                    wavearray.append(datos)


            for i in range(0, (self.tamano/2)):#mi

                    datos = math.sin((2*math.pi*329.63*i)/self.SamplingRate)

                    wavearray.append(datos)

            for i in range(0, (self.tamano/2)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)


            for i in range(0, (self.tamano)):#sol

                    datos = math.sin((2*math.pi*392*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, self.tamano):

                    datos = math.sin((2*math.pi*440*i)/self.SamplingRate)#la

                    wavearray.append(datos)

            for i in range(0, (self.tamano)):#fa

                    datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                    wavearray.append(datos)

            for i in range(0, (self.tamano)):#re

                    datos = math.sin((2*math.pi*293.66*i)/self.SamplingRate)

                    wavearray.append(datos)


            for i in range(0, (self.tamano*2)):#re
                    datos = math.sin((2*math.pi*293.66*i)/self.SamplingRate)

                    wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#re
                 datos = math.sin((2*math.pi*0*i)/self.SamplingRate)

                 wavearray.append(datos)
            for i in range(0, (self.tamano*2)):# comps silencio
             datos = math.sin((2*math.pi*0*i)/self.SamplingRate)

             wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#fa
                 datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)

                 wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#re
                 datos = math.sin((2*math.pi*293.66*i)/self.SamplingRate)

                 wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#reb
                     datos = math.sin((2*math.pi*277.18*i)/self.SamplingRate)

                     wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#mi
                 datos = math.sin((2*math.pi*329.63*i)/self.SamplingRate)

                 wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#la
                 datos = math.sin((2*math.pi*440*i)/self.SamplingRate)

                 wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#fa
                 datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)
                 wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#sol
                 datos = math.sin((2*math.pi*392*i)/self.SamplingRate)
                 wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#mi
                 datos = math.sin((2*math.pi*329.63*i)/self.SamplingRate)
                 wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#fa
                 datos = math.sin((2*math.pi*349.23*i)/self.SamplingRate)
                 wavearray.append(datos)
            for i in range(0, (self.tamano*2)):#fa
                 datos = math.sin((2*math.pi*440*i)/self.SamplingRate)
                 wavearray.append(datos)








            FinalData = np.asarray(wavearray)

            return FinalData
            #return wavearray



        def leveladjust(self, datos, bits, level):
            peaklevel = max(abs(datos))
            print peaklevel
            valueLevel = (10**(level/20))*((2**16)/2.0)
            valueAdjust = valueLevel / float(peaklevel)
            datosAjustados = datos * valueAdjust
            print max(datosAjustados)
            return datosAjustados
